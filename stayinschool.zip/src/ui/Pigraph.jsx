import React, { useState } from 'react'

const pigraph = () => {
    let [len,setLen]=useState(0);
  return (
    <div>pigraph</div>
  )
}

export default pigraph;