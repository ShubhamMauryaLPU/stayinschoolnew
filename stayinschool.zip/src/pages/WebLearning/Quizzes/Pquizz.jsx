import React from 'react'

const Pquizz = () => {
  return (
    <div>Pquizz</div>
  )
}

export default Pquizz