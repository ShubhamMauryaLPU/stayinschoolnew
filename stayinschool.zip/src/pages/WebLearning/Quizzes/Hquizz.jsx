import React from 'react'

const Hquizz = () => {
  return (
    <div>Hquizz</div>
  )
}

export default Hquizz