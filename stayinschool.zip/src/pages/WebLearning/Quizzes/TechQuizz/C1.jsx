import React from 'react'
import cQuiz from '../../../../data/quizz/C1'
import Quizz from '../../../../components/Quizz'
const C1 = () => {
  return (
    <Quizz name={"C"} quizzData={cQuiz} />
  )
}

export default C1