import React from 'react'

const PrimaryLearn = () => {
  return (
    <div>PrimaryLearn</div>
  )
}

export default PrimaryLearn