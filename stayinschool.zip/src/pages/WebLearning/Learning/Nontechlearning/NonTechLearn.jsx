import React from 'react'

const NonTechLearn = () => {
  return (
    <div>NonTechLearn</div>
  )
}

export default NonTechLearn