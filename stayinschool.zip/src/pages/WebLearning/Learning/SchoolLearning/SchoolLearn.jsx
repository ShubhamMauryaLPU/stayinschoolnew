import React from 'react'

const SchoolLearn = () => {
  return (
    <div>SchoolLearn</div>
  )
}

export default SchoolLearn