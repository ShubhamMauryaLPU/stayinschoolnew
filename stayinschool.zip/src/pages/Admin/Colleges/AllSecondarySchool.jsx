import React from 'react'

const AllSecondarySchool = () => {
  return (
    <div>AllSecondarySchool</div>
  )
}

export default AllSecondarySchool