import React from 'react'

const HighSchool = () => {
  return (
    <div>HighSchool</div>
  )
}

export default HighSchool