import React from 'react'

const AllPrimarySchool = () => {
  return (
    <div>AllPrimarySchool</div>
  )
}

export default AllPrimarySchool