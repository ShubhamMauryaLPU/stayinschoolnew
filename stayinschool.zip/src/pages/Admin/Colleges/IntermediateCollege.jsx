import React from 'react'

const IntermediateCollege = () => {
  return (
    <div>IntermediateCollege</div>
  )
}

export default IntermediateCollege